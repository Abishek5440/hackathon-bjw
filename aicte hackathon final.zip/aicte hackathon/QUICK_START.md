# 🚀 Her Defense - Quick Start Guide

## ⚠️ 404 Error Fix

If you're getting 404 errors, follow these steps:

---

## Step 1: Start Backend Server

**Option A: Double-click**
- `start_backend.bat`

**Option B: Command Line**
```bash
cd "C:\Users\chall\Desktop\aicte hackathon"
python -m backend.app
```

**Verify it's running:**
- Open: http://localhost:5000/api/health
- Should show: `{"status":"ok"}`

---

## Step 2: Start Frontend Server

**⚠️ IMPORTANT:** Don't open HTML files directly (double-click). Use a web server!

**Option A: Double-click**
- `start_server.bat`

**Option B: Command Line**
```bash
cd "C:\Users\chall\Desktop\aicte hackathon"
python -m http.server 8000
```

**Then open in browser:**
- http://localhost:8000

---

## Step 3: Access the Application

1. **Frontend:** http://localhost:8000
2. **Backend API:** http://localhost:5000/api/health

---

## ✅ Why This Fixes 404 Errors

### Problem 1: Backend Not Running
- **Symptom:** API calls return 404
- **Fix:** Start backend with `python -m backend.app`

### Problem 2: File:// Protocol
- **Symptom:** CORS errors, 404s when accessing API
- **Fix:** Use HTTP server (`python -m http.server 8000`)

### Problem 3: Missing Routes
- **Symptom:** Specific pages return 404
- **Fix:** All routes are defined in `backend/routes.py`

---

## 📋 All Available Routes

### Backend API (`/api/*`)
- `GET /api/health` - Health check
- `POST /api/auth/login` - Login/Register
- `GET /api/me` - User profile
- `GET /api/contacts` - List contacts
- `POST /api/contacts` - Add contact
- `POST /api/sos` - Trigger SOS
- `GET /api/logs` - Get logs
- `POST /api/journey` - Start journey
- `DELETE /api/journey` - Cancel journey

### Frontend Pages
- `/index.html` - Onboarding
- `/dashboard.html` - Main dashboard
- `/features.html` - All features
- `/contacts.html` - Emergency contacts
- `/settings.html` - Settings
- `/logs.html` - Distress logs
- `/journey.html` - Journey guardian
- `/silent-sos.html` - Silent SOS feature
- `/shake-tap.html` - Shake + Tap feature
- `/keypad.html` - Secret keypad
- `/morse-code.html` - Morse code
- `/screamer.html` - Screamer alarm
- `/audio-buffer.html` - Audio buffer
- `/tamper.html` - Tamper detection
- `/sms-alerts.html` - SMS alerts
- `/safe-radius.html` - Safe radius
- `/fake.html` - Fake screen
- `/panic.html` - Panic button

---

## 🐛 Still Getting 404?

1. **Check Backend:**
   ```bash
   # Test in browser or PowerShell:
   Invoke-WebRequest -Uri "http://localhost:5000/api/health"
   ```

2. **Check Frontend Server:**
   - Make sure you're using http://localhost:8000 (not file://)
   - Check browser console (F12) for errors

3. **Check Files:**
   - All HTML files should be in project root
   - Verify `backend/routes.py` has all endpoints

4. **Check Ports:**
   - Backend: Port 5000
   - Frontend: Port 8000
   - Make sure nothing else is using these ports

---

## 📁 Project Structure

```
aicte hackathon/
├── backend/
│   ├── app.py              ← Flask app
│   ├── routes.py           ← API endpoints
│   ├── models.py           ← Database models
│   ├── db.py               ← Database instance
│   ├── config.py           ← Configuration
│   └── herdefense.db       ← SQLite database
├── index.html              ← Onboarding
├── dashboard.html          ← Dashboard
├── features.html           ← Features page
├── *.html                  ← Feature pages
├── script.js               ← Frontend logic
├── style.css               ← Styles
├── start_backend.bat       ← Start backend
└── start_server.bat        ← Start frontend server
```

---

**Everything should work now! 🎉**

