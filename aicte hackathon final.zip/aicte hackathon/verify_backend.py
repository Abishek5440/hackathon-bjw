#!/usr/bin/env python3
"""Verify backend connections and show database status"""

import sys
import os

print("=" * 60)
print("HER DEFENSE - BACKEND CONNECTION VERIFICATION")
print("=" * 60)
print()

# Check db.py
print("1. Checking db.py...")
try:
    from backend.db import db
    print("   ✓ db.py is CORRECT")
    print("   ✓ SQLAlchemy instance created")
    print(f"   ✓ Type: {type(db)}")
except Exception as e:
    print(f"   ✗ Error: {e}")
    sys.exit(1)

# Check config
print("\n2. Checking config.py...")
try:
    from backend.config import Config
    print("   ✓ config.py loaded")
    print(f"   ✓ Database URI: {Config.SQLALCHEMY_DATABASE_URI}")
    db_path = Config.SQLALCHEMY_DATABASE_URI.replace("sqlite:///", "")
    print(f"   ✓ Database path: {db_path}")
except Exception as e:
    print(f"   ✗ Error: {e}")
    sys.exit(1)

# Check models
print("\n3. Checking models.py...")
try:
    from backend.models import User, Contact, SOSEvent, JourneyTimer, AlertMessage
    print("   ✓ All models imported successfully")
    print("   ✓ User model")
    print("   ✓ Contact model")
    print("   ✓ SOSEvent model")
    print("   ✓ JourneyTimer model")
    print("   ✓ AlertMessage model")
except Exception as e:
    print(f"   ✗ Error: {e}")
    sys.exit(1)

# Check app creation
print("\n4. Checking app.py...")
try:
    from backend.app import app
    print("   ✓ Flask app created")
    print("   ✓ Database initialized")
    print("   ✓ Routes registered")
except Exception as e:
    print(f"   ✗ Error: {e}")
    sys.exit(1)

# Check database file
print("\n5. Checking database file...")
db_file = os.path.join(os.path.dirname(__file__), "backend", "herdefense.db")
if os.path.exists(db_file):
    size = os.path.getsize(db_file)
    print(f"   ✓ Database file exists: {db_file}")
    print(f"   ✓ Size: {size / 1024:.2f} KB")
else:
    print(f"   ⚠ Database file not created yet")
    print(f"   → Will be created when backend starts")

print("\n" + "=" * 60)
print("✓ ALL BACKEND CONNECTIONS VERIFIED!")
print("=" * 60)
print()
print("Backend is ready to run!")
print("Database will be created at:", db_file)
print()

