// Swipe functionality for feature cards
let currentIndex = 0;
let isDragging = false;
let startX = 0;
let currentX = 0;
let translateX = 0;
let cards = [];
let totalCards = 0;

function initSwipe() {
  const wrapper = document.getElementById('swipeWrapper');
  if (!wrapper) return;
  
  cards = Array.from(wrapper.querySelectorAll('.feature-card'));
  totalCards = cards.length;
  
  if (totalCards === 0) return;
  
  // Create dots
  createDots();
  
  // Update initial position
  updatePosition();
  
  // Touch events
  wrapper.addEventListener('touchstart', handleStart, { passive: true });
  wrapper.addEventListener('touchmove', handleMove, { passive: true });
  wrapper.addEventListener('touchend', handleEnd);
  
  // Mouse events
  wrapper.addEventListener('mousedown', handleStart);
  wrapper.addEventListener('mousemove', handleMove);
  wrapper.addEventListener('mouseup', handleEnd);
  wrapper.addEventListener('mouseleave', handleEnd);
  
  // Button controls
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  
  if (prevBtn) prevBtn.addEventListener('click', () => goToSlide(currentIndex - 1));
  if (nextBtn) nextBtn.addEventListener('click', () => goToSlide(currentIndex + 1));
  
  // Keyboard navigation
  document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowLeft') goToSlide(currentIndex - 1);
    if (e.key === 'ArrowRight') goToSlide(currentIndex + 1);
  });
}

function createDots() {
  const dotsContainer = document.getElementById('swipeDots');
  if (!dotsContainer) return;
  
  dotsContainer.innerHTML = '';
  
  for (let i = 0; i < totalCards; i++) {
    const dot = document.createElement('div');
    dot.className = 'swipe-dot';
    if (i === 0) dot.classList.add('active');
    dot.addEventListener('click', () => goToSlide(i));
    dotsContainer.appendChild(dot);
  }
}

function updateDots() {
  const dots = document.querySelectorAll('.swipe-dot');
  dots.forEach((dot, index) => {
    dot.classList.toggle('active', index === currentIndex);
  });
}

function updatePosition() {
  const wrapper = document.getElementById('swipeWrapper');
  if (!wrapper) return;
  
  const cardWidth = wrapper.offsetWidth;
  const gap = 24;
  const offset = -(currentIndex * (cardWidth + gap));
  
  wrapper.style.transform = `translateX(${offset}px)`;
  updateDots();
  
  // Update button states
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  
  if (prevBtn) prevBtn.style.opacity = currentIndex === 0 ? '0.5' : '1';
  if (nextBtn) nextBtn.style.opacity = currentIndex === totalCards - 1 ? '0.5' : '1';
}

function goToSlide(index) {
  if (index < 0) index = 0;
  if (index >= totalCards) index = totalCards - 1;
  
  currentIndex = index;
  updatePosition();
}

function handleStart(e) {
  isDragging = true;
  startX = e.type === 'touchstart' ? e.touches[0].clientX : e.clientX;
  translateX = 0;
  
  const wrapper = document.getElementById('swipeWrapper');
  if (wrapper) {
    wrapper.style.transition = 'none';
  }
}

function handleMove(e) {
  if (!isDragging) return;
  
  currentX = e.type === 'touchmove' ? e.touches[0].clientX : e.clientX;
  translateX = currentX - startX;
  
  const wrapper = document.getElementById('swipeWrapper');
  if (!wrapper) return;
  
  const cardWidth = wrapper.offsetWidth;
  const gap = 24;
  const baseOffset = -(currentIndex * (cardWidth + gap));
  
  wrapper.style.transform = `translateX(${baseOffset + translateX}px)`;
}

function handleEnd() {
  if (!isDragging) return;
  isDragging = false;
  
  const wrapper = document.getElementById('swipeWrapper');
  if (wrapper) {
    wrapper.style.transition = 'transform 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
  }
  
  const threshold = 50; // Minimum drag distance to trigger slide change
  
  if (Math.abs(translateX) > threshold) {
    if (translateX > 0 && currentIndex > 0) {
      goToSlide(currentIndex - 1);
    } else if (translateX < 0 && currentIndex < totalCards - 1) {
      goToSlide(currentIndex + 1);
    } else {
      updatePosition(); // Snap back
    }
  } else {
    updatePosition(); // Snap back if not enough drag
  }
}

// Auto-play (optional)
let autoPlayInterval = null;

function startAutoPlay() {
  if (autoPlayInterval) return;
  
  autoPlayInterval = setInterval(() => {
    if (currentIndex < totalCards - 1) {
      goToSlide(currentIndex + 1);
    } else {
      goToSlide(0); // Loop back to start
    }
  }, 5000); // Change slide every 5 seconds
}

function stopAutoPlay() {
  if (autoPlayInterval) {
    clearInterval(autoPlayInterval);
    autoPlayInterval = null;
  }
}

// Initialize on page load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initSwipe);
} else {
  initSwipe();
}

// Pause auto-play on user interaction
document.addEventListener('mousedown', stopAutoPlay);
document.addEventListener('touchstart', stopAutoPlay);

