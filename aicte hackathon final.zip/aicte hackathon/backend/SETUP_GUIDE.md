# Backend Setup Guide for Her Defense

## Option 1: Quick Setup (No Database - Recommended for Testing)

This setup runs the backend without MySQL, perfect for testing. All features will work, but data won't persist in a database.

### Steps:

1. **Navigate to backend folder:**
   ```bash
   cd backend
   ```

2. **Create virtual environment (optional but recommended):**
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the backend:**
   ```bash
   python -m backend.app
   ```

The backend will start on `http://localhost:5000/api`

**Note:** Without a database, the app will still work but won't persist data. The frontend will use localStorage instead.

---

## Option 2: Full Setup with MySQL (For Production)

### Prerequisites:
- MySQL installed and running
- MySQL root password

### Steps:

1. **Install MySQL** (if not installed):
   - Download from: https://dev.mysql.com/downloads/installer/
   - Or use XAMPP/WAMP which includes MySQL

2. **Create the database:**
   ```bash
   mysql -u root -p
   ```
   Then in MySQL:
   ```sql
   CREATE DATABASE IF NOT EXISTS sdt;
   EXIT;
   ```

3. **Create database tables:**
   ```bash
   mysql -u root -p sdt < schema.sql
   ```

4. **Set up Python environment:**
   ```bash
   cd backend
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   ```

5. **Configure database connection:**
   
   Edit `backend/config.py` or set environment variables:
   ```bash
   set DATABASE_URI=mysql+pymysql://root:YOUR_PASSWORD@localhost:3306/sdt
   set SECRET_KEY=your-secret-key-here
   set JWT_SECRET_KEY=your-jwt-secret-key-here
   ```

6. **Run the backend:**
   ```bash
   python -m backend.app
   ```

---

## Option 3: Setup with SQLite (Simpler than MySQL)

If you want database persistence but don't want to install MySQL, we can modify the config to use SQLite instead.

### Steps:

1. **Modify `backend/config.py`:**
   Change the DATABASE_URI to:
   ```python
   SQLALCHEMY_DATABASE_URI = os.environ.get(
       "DATABASE_URI",
       "sqlite:///herdefense.db",  # SQLite instead of MySQL
   )
   ```

2. **Install dependencies:**
   ```bash
   cd backend
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. **Run the backend:**
   ```bash
   python -m backend.app
   ```

The database file `herdefense.db` will be created automatically.

---

## Optional: SMS Setup (Twilio)

If you want SMS alerts to work:

1. **Sign up for Twilio:** https://www.twilio.com/try-twilio
2. **Get your credentials:**
   - Account SID
   - Auth Token
   - Phone number

3. **Set environment variables:**
   ```bash
   set SMS_ENABLED=true
   set TWILIO_ACCOUNT_SID=ACxxxxx
   set TWILIO_AUTH_TOKEN=xxxxx
   set TWILIO_FROM_NUMBER=+1234567890
   ```

---

## Testing the Backend

Once running, test the health endpoint:
- Open browser: http://localhost:5000/api/health
- Should return: `{"status":"ok"}`

Or test from command line:
```bash
curl http://localhost:5000/api/health
```

---

## Troubleshooting

**Port 5000 already in use:**
- Change port in `backend/app.py` or set environment variable: `set PORT=5001`

**MySQL connection error:**
- Make sure MySQL is running
- Check username/password in DATABASE_URI
- Verify database `sdt` exists

**Import errors:**
- Make sure you're in the backend directory
- Activate virtual environment
- Reinstall: `pip install -r requirements.txt`

