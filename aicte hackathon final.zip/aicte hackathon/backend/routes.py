from datetime import datetime, timedelta

from flask import Blueprint, jsonify, request
from flask_jwt_extended import (
    create_access_token,
    get_jwt_identity,
    jwt_required,
)

from .db import db
from .models import AlertMessage, Contact, JourneyTimer, SOSEvent, User
from .sms import send_alert

api = Blueprint("api", __name__, url_prefix="/api")


@api.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"}), 200


@api.route("/auth/login", methods=["POST"])
def login():
    payload = request.get_json() or {}
    phone = (payload.get("phone") or "").strip()
    name = (payload.get("name") or "").strip() or None
    if not phone:
        return jsonify({"error": "phone is required"}), 400

    user = User.query.filter_by(phone=phone).first()
    created = False
    if not user:
        user = User(phone=phone, name=name)
        db.session.add(user)
        created = True
    elif name and not user.name:
        user.name = name

    db.session.commit()
    token = create_access_token(identity=user.id, expires_delta=timedelta(days=2))
    return jsonify({"token": token, "created": created, "user": {"id": user.id, "name": user.name, "phone": user.phone}})


@api.route("/me", methods=["GET", "PUT"])
@jwt_required()
def me():
    user_id = get_jwt_identity()
    user = User.query.get_or_404(user_id)
    if request.method == "PUT":
        payload = request.get_json() or {}
        user.name = payload.get("name", user.name)
        user.email = payload.get("email", user.email)
        db.session.commit()
    return jsonify({"id": user.id, "name": user.name, "phone": user.phone, "email": user.email})


@api.route("/contacts", methods=["GET", "POST"])
@jwt_required()
def contacts():
    user_id = get_jwt_identity()
    if request.method == "POST":
        payload = request.get_json() or {}
        name = (payload.get("name") or "").strip()
        phone = (payload.get("phone") or "").strip()
        if not name or not phone:
            return jsonify({"error": "name and phone are required"}), 400
        contact = Contact(name=name, phone=phone, user_id=user_id)
        db.session.add(contact)
        db.session.commit()
        return jsonify({"id": contact.id, "name": contact.name, "phone": contact.phone}), 201

    items = Contact.query.filter_by(user_id=user_id).order_by(Contact.created_at.desc()).all()
    return jsonify([{"id": c.id, "name": c.name, "phone": c.phone} for c in items])


@api.route("/contacts/<int:contact_id>", methods=["PUT", "DELETE"])
@jwt_required()
def contact_detail(contact_id: int):
    user_id = get_jwt_identity()
    contact = Contact.query.filter_by(id=contact_id, user_id=user_id).first_or_404()

    if request.method == "PUT":
        payload = request.get_json() or {}
        contact.name = payload.get("name", contact.name)
        contact.phone = payload.get("phone", contact.phone)
        db.session.commit()
        return jsonify({"id": contact.id, "name": contact.name, "phone": contact.phone})

    db.session.delete(contact)
    db.session.commit()
    return jsonify({"status": "deleted"})


@api.route("/sos", methods=["POST"])
@jwt_required()
def sos():
    user_id = get_jwt_identity()
    payload = request.get_json() or {}
    event = SOSEvent(
        user_id=user_id,
        mode=payload.get("mode") or "quick",
        note=payload.get("note"),
        location_lat=payload.get("location_lat"),
        location_lng=payload.get("location_lng"),
        offline=bool(payload.get("offline")),
    )
    db.session.add(event)
    db.session.commit()

    # SMS blast to user's contacts if SMS is enabled
    contacts = Contact.query.filter_by(user_id=user_id).all()
    numbers = [c.phone for c in contacts if c.phone]
    if numbers:
        parts = [f"SOS from {payload.get('name') or 'user'}", f"Mode: {event.mode}"]
        if payload.get("note"):
            parts.append(f"Note: {payload['note']}")
        if payload.get("location_lat") and payload.get("location_lng"):
            parts.append(f"Location: {payload['location_lat']},{payload['location_lng']}")
        send_alert(numbers, " | ".join(parts))

    return jsonify({"id": event.id, "created_at": event.created_at.isoformat()}), 201


@api.route("/alert", methods=["POST"])
@jwt_required()
def alert():
    """
    Targeted alert sender.
    Body:
    - contact_ids: optional list of contact IDs belonging to the user
    - numbers: optional list of E.164 phone numbers
    - body: optional custom message; otherwise a default template is used
    - template_id: optional template key (stored for audit)
    """
    user_id = get_jwt_identity()
    payload = request.get_json() or {}

    contact_ids = payload.get("contact_ids") or []
    numbers = payload.get("numbers") or []
    if not isinstance(numbers, list):
        return jsonify({"error": "numbers must be a list"}), 400

    # If contact_ids provided, fetch those; else if no numbers, default to all contacts.
    selected_numbers = list(numbers)
    if contact_ids:
        items = Contact.query.filter(Contact.user_id == user_id, Contact.id.in_(contact_ids)).all()
        selected_numbers.extend([c.phone for c in items if c.phone])
    elif not selected_numbers:
        items = Contact.query.filter_by(user_id=user_id).all()
        selected_numbers.extend([c.phone for c in items if c.phone])

    selected_numbers = [n for n in {n.strip() for n in selected_numbers if n}]  # dedupe / clean

    if not selected_numbers:
        return jsonify({"error": "no contacts available"}), 400

    message_body = payload.get("body") or "Emergency alert: I need help. Please respond."
    template_id = payload.get("template_id")

    results = send_alert(selected_numbers, message_body)

    # Persist status per number
    for res in results:
        msg = AlertMessage(
            user_id=user_id,
            to_number=res.get("to"),
            body=message_body,
            status=res.get("status", "unknown"),
            template_id=template_id,
        )
        db.session.add(msg)
    db.session.commit()

    return jsonify({"results": results}), 201


@api.route("/logs", methods=["GET"])
@jwt_required()
def logs():
    user_id = get_jwt_identity()
    events = SOSEvent.query.filter_by(user_id=user_id).order_by(SOSEvent.created_at.desc()).limit(50).all()
    return jsonify(
        [
            {
                "id": e.id,
                "created_at": e.created_at.isoformat(),
                "mode": e.mode,
                "note": e.note,
                "offline": e.offline,
                "location_lat": e.location_lat,
                "location_lng": e.location_lng,
            }
            for e in events
        ]
    )


@api.route("/journey", methods=["POST", "DELETE"])
@jwt_required()
def journey():
    user_id = get_jwt_identity()
    if request.method == "DELETE":
        JourneyTimer.query.filter_by(user_id=user_id, active=True).update({"active": False})
        db.session.commit()
        return jsonify({"status": "cancelled"})

    payload = request.get_json() or {}
    try:
        eta = int(payload.get("eta_minutes"))
    except (TypeError, ValueError):
        eta = None
    if not eta:
        return jsonify({"error": "eta_minutes is required"}), 400
    destination = payload.get("destination")
    expires_at = datetime.utcnow() + timedelta(minutes=eta)
    timer = JourneyTimer(
        user_id=user_id,
        eta_minutes=eta,
        destination=destination,
        active=True,
        expires_at=expires_at,
    )
    db.session.add(timer)
    db.session.commit()
    return jsonify({"id": timer.id, "expires_at": expires_at.isoformat()})


