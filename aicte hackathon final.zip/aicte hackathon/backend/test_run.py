#!/usr/bin/env python3
"""Test script to run backend and show status"""

import sys
import time
import requests
from pathlib import Path

print("=" * 60)
print("HER DEFENSE - BACKEND SERVER PREVIEW")
print("=" * 60)
print()

# Check database file location
db_path = Path(__file__).parent / "herdefense.db"
print(f"📁 Database Location: {db_path}")
print(f"   Exists: {'✓ YES' if db_path.exists() else '✗ NO (will be created on startup)'}")
print()

# Try to start the backend
print("🚀 Starting Flask backend server...")
print("   This will run in the background")
print()
print("   Server URL: http://localhost:5000/api")
print("   Health Check: http://localhost:5000/api/health")
print()

# Import and run
try:
    from backend.app import app
    print("✓ Backend modules loaded successfully")
    print()
    print("=" * 60)
    print("SERVER STARTING...")
    print("=" * 60)
    print()
    print("Press Ctrl+C to stop the server")
    print()
    
    # Run the app
    app.run(host='0.0.0.0', port=5000, debug=True)
    
except KeyboardInterrupt:
    print("\n\nServer stopped by user")
except Exception as e:
    print(f"\n✗ Error starting server: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

