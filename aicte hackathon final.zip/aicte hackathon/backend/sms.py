from typing import Iterable, List, Optional

from flask import current_app
from twilio.rest import Client


def _client() -> Optional[Client]:
    cfg = current_app.config
    if not cfg.get("SMS_ENABLED"):
        return None
    sid = cfg.get("TWILIO_ACCOUNT_SID")
    token = cfg.get("TWILIO_AUTH_TOKEN")
    if not sid or not token:
        return None
    return Client(sid, token)


def send_alert(numbers: Iterable[str], body: str) -> List[dict]:
    """
    Send SMS to a list of E.164 numbers.
    Silently no-ops if SMS is disabled/misconfigured.
    Returns a list of status dicts per number.
    """
    client = _client()
    if not client:
        return []

    from_number = current_app.config.get("TWILIO_FROM_NUMBER")
    if not from_number:
        return []

    results: List[dict] = []

    for num in numbers:
        try:
            msg = client.messages.create(
                to=num,
                from_=from_number,
                body=body[:480],  # keep concise
            )
            results.append({"to": num, "status": "sent", "sid": getattr(msg, "sid", None)})
        except Exception:
            # avoid crashing SOS flow on SMS errors
            results.append({"to": num, "status": "failed"})

    return results


