import os


class Config:
    """Base configuration for the Flask app."""

    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key")
    
    # Database URI - Using SQLite by default (no setup required)
    # SQLite database file will be created automatically in the backend folder
    _base_dir = os.path.dirname(os.path.abspath(__file__))
    _db_path = os.path.join(_base_dir, "herdefense.db")
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URI",
        f"sqlite:///{_db_path}",  # SQLite database file in backend folder
    )
    
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY", "dev-jwt-secret")
    CORS_SUPPORTS_CREDENTIALS = True

    # SMS (Twilio) settings
    SMS_ENABLED = os.environ.get("SMS_ENABLED", "false").lower() == "true"
    TWILIO_ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID")
    TWILIO_AUTH_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN")
    TWILIO_FROM_NUMBER = os.environ.get("TWILIO_FROM_NUMBER")


