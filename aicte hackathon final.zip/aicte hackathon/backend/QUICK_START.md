# Quick Start - Backend Setup

## Easiest Way (Windows)

1. **Double-click `quick_start.bat`** in the `backend` folder
   - This will automatically:
     - Create a virtual environment
     - Install all dependencies
     - Start the backend server

2. **The backend will run on:** `http://localhost:5000/api`

3. **To stop:** Press `Ctrl+C` in the terminal

---

## Manual Setup (Any OS)

### Step 1: Navigate to backend folder
```bash
cd backend
```

### Step 2: Create virtual environment (optional but recommended)
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac/Linux
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Run the backend
```bash
python -m backend.app
```

---

## What You'll See

When the backend starts successfully, you'll see:
```
✓ Database initialized successfully
 * Running on http://0.0.0.0:5000
```

The backend uses **SQLite by default** (no MySQL setup needed!). A file called `herdefense.db` will be created automatically.

---

## Testing

Open your browser and go to:
- **Health check:** http://localhost:5000/api/health
- Should show: `{"status":"ok"}`

Your frontend will now detect the backend and show **Online Mode**!

---

## Troubleshooting

**Port 5000 already in use?**
- Change the port in `backend/app.py` line 31, or set: `set PORT=5001`

**Python not found?**
- Make sure Python 3.7+ is installed
- Check: `python --version` or `python3 --version`

**Import errors?**
- Make sure you activated the virtual environment
- Reinstall: `pip install -r requirements.txt`

**Want to use MySQL instead?**
- See `SETUP_GUIDE.md` for MySQL setup instructions
- Or set: `set USE_SQLITE=false` before running

---

## That's It!

Once the backend is running, refresh your frontend page and it should show **Online Mode** with all features available!

