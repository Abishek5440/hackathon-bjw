#!/bin/bash

echo "===================================="
echo "Her Defense Backend - Flask + SQLite"
echo "===================================="
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python from https://www.python.org/"
    exit 1
fi

echo "[1/3] Checking virtual environment..."
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
    echo "Virtual environment created."
else
    echo "Virtual environment found."
fi

echo ""
echo "[2/3] Activating virtual environment and installing dependencies..."
source venv/bin/activate
pip install -r requirements.txt --quiet

echo ""
echo "[3/3] Starting Flask backend with SQLite..."
echo ""
echo "===================================="
echo "Backend Configuration:"
echo "- Database: SQLite (herdefense.db)"
echo "- Server: http://localhost:5000/api"
echo "===================================="
echo ""
echo "Press Ctrl+C to stop the server"
echo ""
python -m backend.app

