# Flask + SQLite Backend Setup

Your backend is now configured to use **Flask with SQLite** - no MySQL installation needed!

## Quick Start (3 Steps)

### Step 1: Navigate to backend folder
```bash
cd backend
```

### Step 2: Install dependencies
```bash
# Create virtual environment (optional but recommended)
python -m venv venv

# Activate it
venv\Scripts\activate  # Windows
# OR
source venv/bin/activate  # Mac/Linux

# Install packages
pip install -r requirements.txt
```

### Step 3: Run the backend
```bash
python -m backend.app
```

**That's it!** The backend will:
- Start on `http://localhost:5000/api`
- Automatically create `herdefense.db` SQLite database file
- Create all necessary tables automatically

---

## Even Easier: Use the Script

**Windows:** Double-click `run_backend.bat` in the backend folder

**Mac/Linux:** Run `bash run_backend.sh` in the backend folder

---

## What Gets Created

When you run the backend:
- **SQLite database:** `herdefense.db` (created automatically in backend folder)
- **Tables created automatically:**
  - `users` - User accounts
  - `contacts` - Emergency contacts
  - `sos_events` - SOS event logs
  - `journey_timers` - Journey tracking
  - `alert_messages` - SMS alert logs

---

## Verify It's Working

1. **Backend should show:**
   ```
   ✓ Database initialized successfully
   * Running on http://0.0.0.0:5000
   ```

2. **Test in browser:** Open http://localhost:5000/api/health
   - Should show: `{"status":"ok"}`

3. **Check your frontend:** Refresh your web page
   - Should now show "Online Mode" instead of "Offline Mode"

---

## Configuration

The backend is configured in `backend/config.py`:
- **Database:** SQLite (`sqlite:///herdefense.db`)
- **Port:** 5000 (change with `set PORT=5001`)
- **CORS:** Enabled (allows frontend to connect)

---

## Troubleshooting

**Port 5000 already in use?**
- Change port: Edit `backend/app.py` line 31, or set `set PORT=5001`

**Module not found errors?**
- Make sure virtual environment is activated
- Reinstall: `pip install -r requirements.txt`

**Database errors?**
- Delete `herdefense.db` and restart - it will recreate automatically

---

## That's It!

Your Flask + SQLite backend is ready! Once running, your frontend will automatically detect it and enable all online features.

