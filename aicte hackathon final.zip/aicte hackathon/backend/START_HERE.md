# How to Run the Backend - Step by Step

## Method 1: Easiest Way (Windows)

**Just double-click:** `run_backend.bat` in the backend folder

That's it! The script will:
- Create virtual environment (if needed)
- Install all dependencies
- Start the Flask server

---

## Method 2: Manual Steps

### Step 1: Open Terminal/Command Prompt
Navigate to the backend folder:
```bash
cd "C:\Users\chall\Desktop\aicte hackathon\backend"
```

### Step 2: Create Virtual Environment (first time only)
```bash
python -m venv venv
```

### Step 3: Activate Virtual Environment
```bash
venv\Scripts\activate
```

You should see `(venv)` in your prompt.

### Step 4: Install Dependencies (first time only)
```bash
pip install -r requirements.txt
```

### Step 5: Run the Backend
```bash
python -m backend.app
```

---

## What You Should See

When it starts successfully:
```
✓ Database initialized successfully
 * Running on http://0.0.0.0:5000
 * Debug mode: on
```

The database file `herdefense.db` will be created automatically in the backend folder.

---

## Test It's Working

1. **Check backend:** Open http://localhost:5000/api/health in browser
   - Should show: `{"status":"ok"}`

2. **Check frontend:** Refresh your web page
   - Should show "Online Mode" instead of "Offline Mode"

---

## To Stop the Server

Press `Ctrl+C` in the terminal

---

## Troubleshooting

**"python is not recognized"**
- Make sure Python is installed and in PATH
- Try `python3` instead of `python`

**"Module not found"**
- Make sure virtual environment is activated (you should see `(venv)`)
- Run: `pip install -r requirements.txt`

**"Port 5000 already in use"**
- Another program is using port 5000
- Change port: Edit `backend/app.py` line 37, change `5000` to `5001`

