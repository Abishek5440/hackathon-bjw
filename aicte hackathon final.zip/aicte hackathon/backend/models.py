from datetime import datetime

from .db import db


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120))
    phone = db.Column(db.String(32), unique=True, nullable=False)
    email = db.Column(db.String(255), unique=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    contacts = db.relationship("Contact", backref="user", lazy=True, cascade="all, delete-orphan")
    sos_events = db.relationship("SOSEvent", backref="user", lazy=True, cascade="all, delete-orphan")
    journeys = db.relationship("JourneyTimer", backref="user", lazy=True, cascade="all, delete-orphan")


class Contact(db.Model):
    __tablename__ = "contacts"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(64), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)


class SOSEvent(db.Model):
    __tablename__ = "sos_events"

    id = db.Column(db.Integer, primary_key=True)
    mode = db.Column(db.String(80), default="quick")
    note = db.Column(db.Text)
    location_lat = db.Column(db.Float)
    location_lng = db.Column(db.Float)
    offline = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)


class JourneyTimer(db.Model):
    __tablename__ = "journey_timers"

    id = db.Column(db.Integer, primary_key=True)
    destination = db.Column(db.String(255))
    eta_minutes = db.Column(db.Integer, nullable=False)
    active = db.Column(db.Boolean, default=True)
    expires_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)


class AlertMessage(db.Model):
  __tablename__ = "alert_messages"

  id = db.Column(db.Integer, primary_key=True)
  user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
  to_number = db.Column(db.String(64), nullable=False)
  body = db.Column(db.Text, nullable=False)
  status = db.Column(db.String(32), default="queued")
  template_id = db.Column(db.String(64))
  created_at = db.Column(db.DateTime, default=datetime.utcnow)

  user = db.relationship("User", backref=db.backref("alert_messages", lazy=True))


