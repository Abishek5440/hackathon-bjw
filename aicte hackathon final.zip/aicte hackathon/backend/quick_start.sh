#!/bin/bash

echo "===================================="
echo "Her Defense Backend - Quick Start"
echo "===================================="
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python from https://www.python.org/"
    exit 1
fi

echo "[1/3] Creating virtual environment..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo "Virtual environment created."
else
    echo "Virtual environment already exists."
fi

echo ""
echo "[2/3] Activating virtual environment and installing dependencies..."
source venv/bin/activate
pip install -r requirements.txt --quiet

echo ""
echo "[3/3] Starting backend server..."
echo ""
echo "Backend will start on http://localhost:5000/api"
echo "Press Ctrl+C to stop the server"
echo ""
python -m backend.app

