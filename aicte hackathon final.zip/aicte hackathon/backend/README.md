# Her Defense – Flask API

Lightweight Flask API with database persistence for the Her Defense web app.

## Quick Start

**Easiest way:** See `QUICK_START.md` for simple setup instructions.

**Windows users:** Double-click `quick_start.bat` to automatically set up and run the backend.

## Default Setup (SQLite - No MySQL Required!)

The backend now uses **SQLite by default** - no database setup needed!

1) Create virtualenv (optional):
```
python -m venv venv
venv\Scripts\activate  # Windows
source venv/bin/activate  # Mac/Linux
```

2) Install deps:
```
pip install -r requirements.txt
```

3) Run the API:
```
python -m backend.app
```

The API listens on `http://localhost:5000/api`. A SQLite database file (`herdefense.db`) will be created automatically.

## MySQL Setup (Optional)

If you prefer MySQL, see `SETUP_GUIDE.md` for detailed instructions.

To use MySQL instead of SQLite:
```
set USE_SQLITE=false
set DATABASE_URI=mysql+pymysql://root:password@localhost:3306/sdt
python -m backend.app
```

## SMS Configuration (Optional)

To enable SMS alerts via Twilio:
```
set SMS_ENABLED=true
set TWILIO_ACCOUNT_SID=ACxxxx
set TWILIO_AUTH_TOKEN=xxxx
set TWILIO_FROM_NUMBER=+1xxxxxxxxxx
```

## Key endpoints
- `POST /api/auth/login` `{phone, name?}` → `{token}`
- `GET/PUT /api/me`
- `GET/POST /api/contacts`
- `PUT/DELETE /api/contacts/:id`
- `POST /api/sos`
- `POST /api/alert` — send SMS to specific contacts/numbers, store status
- `GET /api/logs`
- `POST /api/journey` / `DELETE /api/journey`

SMS notes
- SMS sending uses Twilio if `SMS_ENABLED=true` and credentials are set; otherwise SOS still logs but skips SMS.
- Messages are sent to all contacts saved for the user. Keep numbers in E.164 format (e.g., +91xxxxxxxxxx).


