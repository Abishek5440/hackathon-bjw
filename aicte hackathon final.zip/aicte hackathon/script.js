// Shared utilities for Her Defense Translator
const qs = (sel, ctx = document) => ctx.querySelector(sel);
const qsa = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

const STORAGE_KEYS = {
  PROFILE: "sdt_profile",
  CONTACTS: "sdt_contacts",
  LOGS: "sdt_logs",
  SETTINGS: "sdt_settings",
  TOKEN: "sdt_token",
};

const SECRET_KEYPAD_CODE = "911#";

// Rolling audio buffer state (demo)
let rollingRecorder = null;
let rollingStream = null;
let rollingChunks = [];
const ROLLING_WINDOW_MS = 20000;

// Minimal backend integration (Flask API)
const API_BASE = window.API_BASE || "http://localhost:5000/api";
let apiReady = false;
let authToken = localStorage.getItem(STORAGE_KEYS.TOKEN) || "";

async function initApi(forceCheck = false) {
  if (apiReady && !forceCheck) return true;
  
  // Reset apiReady if forcing a check
  if (forceCheck) apiReady = false;
  
  try {
    // Add timeout to prevent hanging
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2000); // 2 second timeout
    
    const res = await fetch(`${API_BASE}/health`, {
      method: 'GET',
      signal: controller.signal,
      mode: 'cors',
      cache: 'no-cache'
    });
    
    clearTimeout(timeoutId);
    
    if (res.ok) {
      apiReady = true;
      console.log('✓ Backend API is available');
      return true;
    }
  } catch (e) {
    // Backend unavailable - this is expected if backend isn't running
    // Silent fallback to local-only mode
    if (e.name !== 'AbortError') {
      console.log('✗ Backend API unavailable at', API_BASE, '- using offline mode');
    }
  }
  apiReady = false;
  return false;
}

function setAuthToken(token) {
  authToken = token;
  if (token) localStorage.setItem(STORAGE_KEYS.TOKEN, token);
}

async function apiRequest(path, options = {}) {
  if (!apiReady) throw new Error("API offline");
  const headers = options.headers || {};
  headers["Content-Type"] = "application/json";
  if (authToken) headers.Authorization = `Bearer ${authToken}`;
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  if (!res.ok) {
    const msg = await res.text();
    throw new Error(msg || "Request failed");
  }
  if (res.status === 204) return null;
  return res.json();
}

const toast = (msg) => {
  const el = qs(".toast");
  if (!el) return;
  el.textContent = msg;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2300);
};

function save(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}
function load(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) ?? fallback;
  } catch (e) {
    return fallback;
  }
}

// Offline handling - checks backend API availability, not just network
async function handleOfflineState() {
  const root = document.body;
  // Check backend availability (this is what determines if features work)
  const backendAvailable = await initApi();
  
  if (!backendAvailable) {
    // Backend unavailable - hide online-only features
    root.classList.add("offline");
    const banner = qs(".offline-banner");
    if (banner) {
      banner.style.display = "flex";
      const bannerText = banner.querySelector("div:last-child");
      if (bannerText) {
        bannerText.textContent = "Offline Mode — Backend unavailable. Online-only features are hidden.";
      }
    }
    console.log('Running in offline mode - backend API not available');
  } else {
    // Backend available - show all features
    root.classList.remove("offline");
    const banner = qs(".offline-banner");
    if (banner) banner.style.display = "none";
    console.log('Running in online mode - backend API available');
  }
}
window.addEventListener("online", () => {
  // Reset to re-check backend when network comes back
  handleOfflineState();
});
window.addEventListener("offline", () => {
  // Network offline doesn't necessarily mean backend is offline
  // But we'll still check backend availability
  handleOfflineState();
});

// Allow manual refresh of backend status (useful for debugging)
window.refreshBackendStatus = async function() {
  await initApi(true); // Force re-check
  await handleOfflineState();
  toast(apiReady ? 'Backend connected' : 'Backend unavailable');
};

// Anti-false alert popup mock
function antiFalseAlert(onTrigger, onCancel) {
  const confirmed = confirm("Confirm SOS activation within 5 seconds? Tap OK twice to trigger.");
  if (confirmed) {
    // require a second confirm to mimic double tap
    const second = confirm("Tap again to trigger SOS.");
    if (second) {
      onTrigger?.();
      logEvent("SOS Triggered", "Anti-false alert confirmed");
      toast("SOS triggered");
    } else {
      onCancel?.();
      toast("SOS cancelled");
    }
  } else {
    onCancel?.();
    toast("SOS cancelled");
  }
}

// Logs
function logEvent(mode, note = "") {
  const logs = load(STORAGE_KEYS.LOGS, []);
  logs.unshift({
    ts: new Date().toLocaleString(),
    mode,
    note,
  });
  save(STORAGE_KEYS.LOGS, logs.slice(0, 40));
  // Try to persist SOS-like events to the backend when available
  if (apiReady && authToken && mode.toLowerCase().includes("sos")) {
    apiRequest("/sos", {
      method: "POST",
      body: { mode, note, offline: !navigator.onLine },
    }).catch(() => {});
  }
}

// Quick SOS button
function bindQuickSOS() {
  const btn = qs(".quick-sos");
  if (!btn) return;
  btn.addEventListener("click", () => {
    antiFalseAlert(
      () => logEvent("Quick SOS"),
      () => logEvent("Cancelled", "Quick SOS cancelled")
    );
  });
}

// Gesture placeholders
function bindGestures() {
  let tapCount = 0;
  let timer;
  document.addEventListener("click", () => {
    tapCount++;
    clearTimeout(timer);
    timer = setTimeout(() => (tapCount = 0), 500);
    if (tapCount === 2) {
      logEvent("Double tap detected");
      toast("Double tap detected");
    }
    if (tapCount === 3) {
      logEvent("Triple tap detected");
      toast("Triple tap detected");
    }
  });
  // Shake placeholder
  window.addEventListener("devicemotion", () => {
    // placeholder hook
  });
}

// Invisible mode toggle
function bindInvisibleToggle() {
  const toggle = qs("#invisibleToggle");
  if (!toggle) return;
  toggle.addEventListener("change", () => {
    document.body.classList.toggle("invisible", toggle.checked);
    toast(toggle.checked ? "Invisible mode: fake screen" : "Normal mode");
  });
}

// Onboarding
function bindOnboarding() {
  const form = qs("#onboardingForm");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    // Build contacts array from paired fields
    const contacts = [];
    for (let i = 1; i <= 2; i++) {
      const name = (data[`contact${i}Name`] || "").trim();
      const phone = (data[`contact${i}Phone`] || "").trim();
      if (name || phone) contacts.push({ name, phone });
    }
    save(STORAGE_KEYS.PROFILE, data);
    if (contacts.length) save(STORAGE_KEYS.CONTACTS, contacts);
    toast("Profile saved");
    const phone = data.phone || "";
    const name = data.name || "";
    initApi().then((ready) => {
      if (ready && phone) {
        apiRequest("/auth/login", {
          method: "POST",
          body: { phone, name },
        })
          .then((resp) => {
            setAuthToken(resp.token);
            // push contacts to backend
            contacts.forEach((c) => {
              if (c.name && c.phone) {
                apiRequest("/contacts", { method: "POST", body: c }).catch(() => {});
              }
            });
            toast("Account linked");
            setTimeout(() => (window.location.href = "dashboard.html"), 400);
          })
          .catch(() => setTimeout(() => (window.location.href = "dashboard.html"), 400));
      } else {
        setTimeout(() => (window.location.href = "dashboard.html"), 500);
      }
    });
  });
  const progressSteps = qsa(".progress .step");
  form.addEventListener("input", () => {
    const filled = qsa(".input", form).filter((i) => i.value.trim()).length;
    progressSteps.forEach((s, idx) => {
      s.classList.toggle("active", idx < filled);
    });
  });
}

// Login mock
function bindLogin() {
  const form = qs("#loginForm");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const phone = qs("[name='phone']", form).value.trim();
    const name = qs("[name='name']", form)?.value?.trim() || "";
    if (!phone) return toast("Enter phone");
    const ready = await initApi();
    if (!ready) {
      toast("Offline login; data stays local");
      return setTimeout(() => (window.location.href = "dashboard.html"), 400);
    }
    try {
      const resp = await apiRequest("/auth/login", {
        method: "POST",
        body: { phone, name },
      });
      setAuthToken(resp.token);
      toast("Logged in");
      setTimeout(() => (window.location.href = "dashboard.html"), 400);
    } catch (err) {
      toast("Login failed");
    }
  });
}

// Contacts CRUD
async function renderContacts() {
  const list = qs("#contactList");
  if (!list) return;
  let contacts = load(STORAGE_KEYS.CONTACTS, []);
  if (apiReady && authToken) {
    try {
      contacts = await apiRequest("/contacts");
      save(STORAGE_KEYS.CONTACTS, contacts);
    } catch (e) {
      // keep local cache
    }
  }
  list.innerHTML = `
    <div class="list-head">
      <span>Name</span>
      <span>Contact number</span>
      <span>Actions</span>
    </div>
  `;
  contacts.forEach((c, idx) => {
    const row = document.createElement("div");
    row.className = "list-item list-row";
    row.innerHTML = `
      <span><strong>${c.name}</strong></span>
      <span class="small">${c.phone}</span>
      <div style="display:flex; gap:8px; justify-content:flex-end; align-items:center;">
        <button class="btn secondary" data-move="${idx}">↑</button>
        <button class="btn danger" data-del="${idx}">Delete</button>
      </div>
    `;
    list.appendChild(row);
  });
}

function bindContacts() {
  const form = qs("#contactForm");
  if (!form) return;
  renderContacts();
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = qs("[name='contactName']").value.trim();
    const phone = qs("[name='contactPhone']").value.trim();
    if (!name || !phone) return toast("Enter contact details");
    const contacts = load(STORAGE_KEYS.CONTACTS, []);
    contacts.push({ name, phone });
    save(STORAGE_KEYS.CONTACTS, contacts);
    if (apiReady && authToken) {
      apiRequest("/contacts", { method: "POST", body: { name, phone } }).catch(() => {});
    }
    form.reset();
    renderContacts();
  });
  qs("#contactList").addEventListener("click", (e) => {
    const del = e.target.dataset.del;
    const move = e.target.dataset.move;
    const contacts = load(STORAGE_KEYS.CONTACTS, []);
    if (del !== undefined) {
      const idx = Number(del);
      const contact = contacts[idx];
      contacts.splice(idx, 1);
      save(STORAGE_KEYS.CONTACTS, contacts);
      if (apiReady && authToken && contact?.id) {
        apiRequest(`/contacts/${contact.id}`, { method: "DELETE" }).catch(() => {});
      }
      renderContacts();
    }
    if (move !== undefined && Number(move) > 0) {
      const i = Number(move);
      [contacts[i - 1], contacts[i]] = [contacts[i], contacts[i - 1]];
      save(STORAGE_KEYS.CONTACTS, contacts);
      renderContacts();
    }
  });
}

// Journey timer mock
function bindJourney() {
  const startBtn = qs("#startJourney");
  const cancelBtn = qs("#cancelJourney");
  const timerLabel = qs("#journeyTimer");
  if (!startBtn || !cancelBtn) return;
  let timer;
  let countdownInterval;
  
  startBtn.addEventListener("click", () => {
    const destination = qs("[name='destination']")?.value?.trim() || "Unknown";
    const minutes = Number(qs("[name='eta']")?.value || 0);
    if (!minutes) return toast("Enter ETA minutes");
    
    // Update UI
    timerLabel.innerHTML = `<div style="font-size: 1.3rem; margin-bottom: 8px;">⏱️ Journey Active</div><div style="font-size: 0.95rem; color: var(--muted);">Destination: ${destination}</div><div style="font-size: 1.1rem; margin-top: 8px; color: var(--accent);">⏰ ${minutes} minutes remaining</div>`;
    timerLabel.classList.add("active");
    
    // Disable start button, enable cancel
    startBtn.disabled = true;
    startBtn.style.opacity = "0.6";
    cancelBtn.disabled = false;
    cancelBtn.style.opacity = "1";
    
    // Start countdown
    let remaining = minutes;
    countdownInterval = setInterval(() => {
      remaining--;
      if (remaining > 0) {
        timerLabel.innerHTML = `<div style="font-size: 1.3rem; margin-bottom: 8px;">⏱️ Journey Active</div><div style="font-size: 0.95rem; color: var(--muted);">Destination: ${destination}</div><div style="font-size: 1.1rem; margin-top: 8px; color: var(--accent);">⏰ ${remaining} minutes remaining</div>`;
      }
    }, 60000); // Update every minute
    
    clearTimeout(timer);
    timer = setTimeout(() => {
      clearInterval(countdownInterval);
      timerLabel.innerHTML = `<div style="font-size: 1.3rem; margin-bottom: 8px; color: var(--danger);">⚠️ Timer Expired!</div><div style="font-size: 0.95rem; color: var(--muted);">Sending alerts to contacts...</div>`;
      alert("Journey timer expired. Sending alerts (mock).");
      logEvent("Journey alert");
      startBtn.disabled = false;
      startBtn.style.opacity = "1";
    }, minutes * 60000); // Use actual minutes
    
    logEvent("Journey started", `Destination: ${destination}, ETA: ${minutes} min`);
    toast(`Journey started to ${destination}`);
  });
  
  cancelBtn.addEventListener("click", () => {
    clearTimeout(timer);
    if (countdownInterval) clearInterval(countdownInterval);
    timerLabel.innerHTML = "⏸️ Timer Idle";
    timerLabel.classList.remove("active");
    logEvent("Journey cancelled");
    toast("Journey cancelled");
    
    // Re-enable start button
    startBtn.disabled = false;
    startBtn.style.opacity = "1";
    cancelBtn.disabled = true;
    cancelBtn.style.opacity = "0.6";
  });
  
  // Initially disable cancel button
  if (cancelBtn) {
    cancelBtn.disabled = true;
    cancelBtn.style.opacity = "0.6";
  }
}

// Fake calculator
function bindCalculator() {
  qsa(".calc-display").forEach((display) => {
    let expr = "";
    display.parentElement.querySelectorAll(".calc-btn").forEach((btn) =>
      btn.addEventListener("click", () => {
        const val = btn.dataset.val;
        if (val === "C") expr = "";
        else if (val === "=") {
          try {
            expr = String(eval(expr || "0"));
          } catch {
            expr = "Err";
          }
        } else expr += val;
        display.textContent = expr || "0";
      })
    );
    display.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      antiFalseAlert(() => logEvent("SOS from fake calculator"));
    });
  });
}

// Morse code
function bindMorse() {
  const dotBtn = qs("#dot");
  const dashBtn = qs("#dash");
  const clearBtn = qs("#clearMorse");
  const output = qs("#morseOutput");
  const translation = qs("#morseTranslation");
  if (!dotBtn) return;
  let code = "";
  const translate = () => {
    translation.textContent = code.includes("... --- ...") ? "SOS" : code.length ? "HELP (mock)" : "";
  };
  const push = (c) => {
    code += c;
    output.textContent = code;
    translate();
  };
  dotBtn.onclick = () => push("•");
  dashBtn.onclick = () => push("—");
  clearBtn.onclick = () => {
    code = "";
    output.textContent = "";
    translation.textContent = "";
  };
}

// Settings toggles
function bindSettings() {
  const toggles = qsa("[data-setting]");
  if (!toggles.length) return;
  const state = load(STORAGE_KEYS.SETTINGS, {});
  toggles.forEach((t) => {
    t.checked = state[t.dataset.setting] ?? false;
    t.addEventListener("change", () => {
      state[t.dataset.setting] = t.checked;
      save(STORAGE_KEYS.SETTINGS, state);
      toast("Settings saved");
    });
  });
}

// Logs page render
function renderLogs() {
  const tbody = qs("#logsBody");
  if (!tbody) return;
  const logs = load(STORAGE_KEYS.LOGS, []) ?? [];
  if (!logs.length) {
    logs.push(
      { ts: new Date().toLocaleString(), mode: "Setup", note: "App initialized" },
      { ts: new Date().toLocaleString(), mode: "Demo", note: "Safe radius ping" }
    );
  }
  
  // Update stats
  const totalEvents = logs.length;
  const sosEvents = logs.filter(l => l.mode && l.mode.toLowerCase().includes("sos")).length;
  const cancelledEvents = logs.filter(l => l.mode && l.mode.toLowerCase().includes("cancel")).length;
  const journeyEvents = logs.filter(l => l.mode && l.mode.toLowerCase().includes("journey")).length;
  
  const totalEl = qs("#totalEvents");
  const sosEl = qs("#sosEvents");
  const cancelledEl = qs("#cancelledEvents");
  const journeyEl = qs("#journeyEvents");
  
  if (totalEl) totalEl.textContent = totalEvents;
  if (sosEl) sosEl.textContent = sosEvents;
  if (cancelledEl) cancelledEl.textContent = cancelledEvents;
  if (journeyEl) journeyEl.textContent = journeyEvents;
  
  // Render table
  tbody.innerHTML = "";
  logs.forEach((l) => {
    const tr = document.createElement("tr");
    const modeIcon = l.mode && l.mode.toLowerCase().includes("sos") ? "🚨" : 
                     l.mode && l.mode.toLowerCase().includes("cancel") ? "✅" :
                     l.mode && l.mode.toLowerCase().includes("journey") ? "🛡️" : "📌";
    tr.innerHTML = `
      <td style="font-weight: 600; color: var(--text);">${l.ts}</td>
      <td><span style="font-size: 1.2rem; margin-right: 8px;">${modeIcon}</span>${l.mode}</td>
      <td>${l.note || "-"}</td>
    `;
    tbody.appendChild(tr);
  });
}

// Safe radius responders mock
function bindSafeRadius() {
  const counter = qs("#responderCount");
  if (!counter) return;
  let num = 5;
  counter.textContent = num;
  setInterval(() => {
    num = Math.max(1, num + (Math.random() > 0.5 ? 1 : -1));
    counter.textContent = num;
  }, 3000);
}

// Rolling buffer toggle
function bindRollingBuffer() {
  const toggle = qs("#rollingBufferToggle");
  const bar = qs("#rollingBar");
  const saveBtn = qs("[data-save-rolling]");
  if (!toggle || !bar) return;
  toggle.addEventListener("change", async () => {
    if (toggle.checked) {
      try {
        await startRollingBuffer(bar);
        toast("Rolling buffer enabled");
      } catch (err) {
        toast("Mic permission denied");
        toggle.checked = false;
      }
    } else {
      stopRollingBuffer(bar);
      toast("Rolling buffer disabled");
    }
  });
  if (saveBtn) {
    saveBtn.addEventListener("click", () => {
      if (!rollingChunks.length) return toast("No audio captured yet");
      downloadRollingBuffer();
    });
  }
}

// Ultrasonic screamer
function bindScreamer() {
  const toggle = qs("#screamerToggle");
  const wave = qs(".screamer-wave");
  if (!toggle || !wave) return;
  toggle.addEventListener("change", () => {
    wave.style.opacity = toggle.checked ? "1" : "0.3";
    logEvent(toggle.checked ? "Ultrasonic armed" : "Ultrasonic off");
  });
}

// Secret keypad trigger
function bindKeypadTrigger() {
  const btn = qs("[data-keypad-trigger]");
  if (!btn) return;
  btn.addEventListener("click", () => {
    const input = prompt("Enter secret code");
    if (input === null) return;
    if (input.trim() === SECRET_KEYPAD_CODE) {
      antiFalseAlert(() => logEvent("Keypad SOS"));
    } else {
      toast("Wrong code");
    }
  });
}

async function initPage() {
  // Check backend availability first to determine offline state
  await handleOfflineState();
  bindQuickSOS();
  bindGestures();
  bindInvisibleToggle();
  bindOnboarding();
  bindLogin();
  bindContacts();
  bindJourney();
  bindCalculator();
  bindMorse();
  bindSettings();
  renderLogs();
  bindSafeRadius();
  bindRollingBuffer();
  bindScreamer();
  bindKeypadTrigger();
}

// Rolling buffer helpers
async function startRollingBuffer(statusEl) {
  rollingChunks = [];
  rollingStream = await navigator.mediaDevices.getUserMedia({ audio: true });
  rollingRecorder = new MediaRecorder(rollingStream);
  rollingRecorder.ondataavailable = (e) => {
    if (e.data && e.data.size > 0) {
      rollingChunks.push({ blob: e.data, ts: Date.now() });
      trimRollingChunks();
    }
  };
  rollingRecorder.start(1000); // collect every second
  if (statusEl) statusEl.textContent = "Capturing last 20 seconds";
}

function stopRollingBuffer(statusEl) {
  if (rollingRecorder && rollingRecorder.state !== "inactive") {
    rollingRecorder.stop();
  }
  if (rollingStream) {
    rollingStream.getTracks().forEach((t) => t.stop());
  }
  rollingRecorder = null;
  rollingStream = null;
  rollingChunks = [];
  if (statusEl) statusEl.textContent = "Buffer off";
}

function trimRollingChunks() {
  const cutoff = Date.now() - ROLLING_WINDOW_MS;
  rollingChunks = rollingChunks.filter((c) => c.ts >= cutoff);
}

function downloadRollingBuffer() {
  trimRollingChunks();
  const blobs = rollingChunks.map((c) => c.blob);
  const combined = new Blob(blobs, { type: "audio/webm" });
  const url = URL.createObjectURL(combined);
  const a = document.createElement("a");
  a.href = url;
  a.download = "sos-last-20s.webm";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  toast("Saved last 20s (webm)");
}

document.addEventListener("DOMContentLoaded", initPage);

