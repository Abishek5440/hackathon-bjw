# 🚀 Her Defense Backend - Live Preview

## ✅ Backend Status

### Server Information
- **Status**: Running
- **URL**: http://localhost:5000/api
- **Database**: SQLite (`backend/herdefense.db`)
- **Port**: 5000

---

## 📁 Database File

**Location**: `backend/herdefense.db`

This file is created automatically when the backend starts. It contains:
- Users table
- Contacts table  
- SOS Events table
- Journey Timers table
- Alert Messages table

---

## 🔌 API Endpoints

### Health Check
```
GET http://localhost:5000/api/health
Response: {"status": "ok"}
```

### Authentication
```
POST http://localhost:5000/api/auth/login
Body: {"phone": "+91xxxxxxxxxx", "name": "User Name"}
Response: {"token": "...", "user": {...}}
```

### User Profile
```
GET http://localhost:5000/api/me
Headers: Authorization: Bearer <token>
Response: {"id": 1, "name": "...", "phone": "...", "email": "..."}
```

### Contacts
```
GET http://localhost:5000/api/contacts
POST http://localhost:5000/api/contacts
PUT http://localhost:5000/api/contacts/:id
DELETE http://localhost:5000/api/contacts/:id
```

### SOS Events
```
POST http://localhost:5000/api/sos
Body: {"mode": "quick", "note": "...", "location_lat": 0.0, "location_lng": 0.0}
```

### Journey Timer
```
POST http://localhost:5000/api/journey
Body: {"eta_minutes": 30, "destination": "Home"}
DELETE http://localhost:5000/api/journey
```

### Logs
```
GET http://localhost:5000/api/logs
Response: [{"id": 1, "mode": "...", "created_at": "...", ...}]
```

---

## 🧪 Test the Backend

### 1. Health Check
Open in browser: http://localhost:5000/api/health

Should show: `{"status":"ok"}`

### 2. Test with curl (if available)
```bash
curl http://localhost:5000/api/health
```

### 3. Test Login
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"phone": "+911234567890", "name": "Test User"}'
```

---

## 🎯 Frontend Integration

When the backend is running:

1. **Frontend automatically detects it**
   - Checks: http://localhost:5000/api/health
   - If successful: Shows "Online Mode"
   - If failed: Shows "Offline Mode"

2. **Online Mode Features**
   - ✓ SMS alerts (if Twilio configured)
   - ✓ Data sync across devices
   - ✓ Persistent storage in database
   - ✓ All SOS events logged to database

3. **Offline Mode Features**
   - ✓ All features work with localStorage
   - ✓ No database required
   - ✗ SMS alerts disabled
   - ✗ No cross-device sync

---

## 📊 Database Schema

The SQLite database contains these tables:

1. **users** - User accounts
   - id, name, phone, email, created_at

2. **contacts** - Emergency contacts
   - id, name, phone, user_id, created_at

3. **sos_events** - SOS event logs
   - id, mode, note, location_lat, location_lng, offline, user_id, created_at

4. **journey_timers** - Journey tracking
   - id, destination, eta_minutes, active, expires_at, user_id, created_at

5. **alert_messages** - SMS alert logs
   - id, user_id, to_number, body, status, template_id, created_at

---

## 🛠️ Management

### Start Backend
```bash
cd backend
python -m backend.app
```

### Stop Backend
Press `Ctrl+C` in the terminal

### View Database
Use any SQLite browser:
- DB Browser for SQLite (free)
- SQLiteStudio (free)
- Or command line: `sqlite3 backend/herdefense.db`

---

## ✨ What's Working

- ✅ Flask server running
- ✅ SQLite database configured
- ✅ CORS enabled (frontend can connect)
- ✅ JWT authentication ready
- ✅ All API endpoints available
- ✅ Database tables auto-created

---

## 🎉 Next Steps

1. **Refresh your frontend page** - It should now show "Online Mode"
2. **Test features** - Try logging in, adding contacts, triggering SOS
3. **Check database** - View `backend/herdefense.db` to see stored data

---

**Backend is ready! Your Her Defense app is now fully functional! 🚀**

